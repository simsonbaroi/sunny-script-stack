module.exports = {
  presets: ['@react-native/babel-preset'],
};